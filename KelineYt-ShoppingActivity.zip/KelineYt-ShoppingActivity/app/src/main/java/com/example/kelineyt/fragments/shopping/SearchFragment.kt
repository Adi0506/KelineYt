package com.example.kelineyt.fragments.shopping

import androidx.fragment.app.Fragment
import com.example.kelineyt.R

class SearchFragment: Fragment(R.layout.fragment_search) {
}